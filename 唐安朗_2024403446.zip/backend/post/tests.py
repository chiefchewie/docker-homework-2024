from django.test import TestCase


# Create your tests here.
# 测试代码见test文件夹，因为测试跨APP，所以放在根目录下
# avoid F401
class BasicTestCase(TestCase):
    pass
