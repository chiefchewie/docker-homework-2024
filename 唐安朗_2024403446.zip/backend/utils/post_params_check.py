# -*- coding: utf-8 -*-


def post_params_check(content):
    return "ok", True
