# -*- coding: utf-8 -*-


def reply_post_params_check(content):
    return "ok", True
