
export const Constants = {
    "post-per-page": 10,
    "preview-content-length": 100,
}